#ifndef __PARAM_H__
#define __PARAM_H__

#include "Base.h"

class CParam
{
public:
	~CParam()   {}
	CParam()    {}
public:
	class CVariable
	{
	public:
		~CVariable()    
		{
			if(!m_holder)
				return;

			delete m_holder;
			m_holder = NULL;
		}

		CVariable()                             { m_holder = NULL; }
		template<typename valueType>
		CVariable(const valueType& value)       { m_holder = new CHandler<valueType>(value); }
	public:
		CVariable(const CVariable& rhs)         { m_holder = rhs.m_holder ? rhs.m_holder->clone() : NULL; }
		CVariable& operator = (const CVariable& rhs)
		{
			CVariable(rhs).swap(*this);
			return *this;
		}
		template<typename valueType>
		CVariable& operator = (const valueType& rhs)
		{
			CVariable(rhs).swap(*this);
			return *this;
		}
	public:
		template<typename valueType>
		valueType& value()                      { return static_cast<CHandler<valueType>* >(m_holder)->m_value; }
	public:
		CVariable& swap(CVariable& rhs)
		{
			std::swap(m_holder, rhs.m_holder);
			return *this;
		}
		bool empty()                            { return !m_holder; }
	private:
		class IHandler
		{
		public:
			virtual ~IHandler()                  {}
		public:
			virtual IHandler* clone() const				= 0;
		};

		template<typename valueType>
		class CHandler : public IHandler
		{
		public:
			~CHandler()                              {}
			CHandler(const valueType& value)         { m_value = value; }
		public:
			virtual IHandler* clone() const          { return new CHandler(m_value); } 
		public:
			valueType m_value;
		private:
			CHandler& operator = (const CHandler& rhs);
		};
	private:
		IHandler* m_holder;
	};
public:
	size_t count()							{ return m_data.size(); }
	void clear()							{ m_data.clear(); }
	bool empty()							{ return m_data.empty(); }
	bool contains(const std::string key)	{ return m_data.find(key) != m_data.end(); }
public:
	CParam& set(const std::string key, bool value)			{ return set<bool>(key, value); }
	CParam& set(const std::string key, int value)			{ return set<int>(key, value); }
	CParam& set(const std::string key, unsigned int value)	{ return set<unsigned int>(key, value); }
	CParam& set(const std::string key, float value)			{ return set<float>(key, value); }
	CParam& set(const std::string key, const char* value)	{ return set<const char*>(key, value); }
	CParam& set(const std::string key, time_t value)		{ return set<time_t>(key, value); }

	template<typename T>
	CParam& set(const std::string key, T& value)
	{
		CVariable var(value);
		m_data[key] = var;
		return *this;
	}
	template<typename T>
	CParam& set(const std::string key, T* value)
	{
		CVariable var(value);
		m_data[key] = var;
		return *this;
	}

	template<typename T>
	int get(const std::string key, T& value)
	{
		dataMap::iterator it = m_data.find(key);
		if(it == m_data.end())
			return -1;

		value = it->second.value<T>();
		return 0;
	}

	template<typename T>
	T& get(const std::string key)
	{
		dataMap::iterator it = m_data.find(key);
		return it->second.value<T>();
	}
private:
	typedef std::map<std::string, CVariable> dataMap;
private:
	dataMap m_data;
};

#endif