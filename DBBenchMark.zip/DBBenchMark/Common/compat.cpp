#include "compat.h"


namespace NSRobot
{
	void sleep(int millionSec)
	{
#ifdef WIN32
		::Sleep(millionSec);
#else
		::usleep(millionSec * 1000);
#endif
	}

#ifdef WIN32
	int gettimeofday(struct timeval* tv, struct timezone* tz)
	{
		struct __timeb64 tb;
		if(_ftime64_s(&tb) != 0)
			return -1;

		tv->tv_sec =  (long)tb.time;
		tv->tv_usec = tb.millitm * 1000;
		return 0;
	} 
#endif

};

