//This code create by CodeEngine,don't modify
#ifndef _RobotNameTABLE_H
 #define _RobotNameTABLE_H
 
 #include "DBCTable.h"

class Table_RobotName:public DBC_Recorder_Loader<Table_RobotName,999,1000>
 {
 public:
 enum _ID
 {
 INVLAID_INDEX=-1,
ID_ID,
ID_FNAME=2,
ID_SNAME,
ID_TAB_CURCOL_COUNT,
MAX_ID=999,
MAX_RECORD=1000
 };
 public:
 bool __Load(DBC_Loader &loader);

private:
 const tchar* m_FName;
 public:
 const tchar* GetFName() const { return m_FName; }

private:
 tint32 m_ID;
 public:
 tint32 GetID() const { return m_ID; }

private:
 const tchar* m_SName;
 public:
 const tchar* GetSName() const { return m_SName; }

};
 
 DECL_TABLE_FUNCTIONS(Table_RobotName);
 
 //bool InitTable_RobotNameTable( const tchar* szFileName );
 //bool InitTable_RobotNameTableFromMemory( const DBCFile& rDB );
 //const Table_RobotName* GetTable_RobotNameByID(tint32 id);
 //const Table_RobotName* GetTable_RobotNameByIndex(tint32 index);
 //tint32 GetTable_RobotNameCount(void);


 #endif
