//This code create by CodeEngine,don't modify
#include "Table_RobotName.h"




bool Table_RobotName::__Load(DBC_Loader & loader)
 {
 __ENTER_FUNCTION
 
 AssertEx(ID_TAB_CURCOL_COUNT==loader.GetFieldsNum(), "RobotName Columns Differ"); 
 loader.ReadDirect(m_FName,(tint32)ID_FNAME);
loader.ReadDirect(m_ID,(tint32)ID_ID);
loader.ReadDirect(m_SName,(tint32)ID_SNAME);

 return true;
 __LEAVE_FUNCTION
 return false;
 }


 DEFINE_SEQUENCE_TABLE_FUNCTIONS(Table_RobotName);



