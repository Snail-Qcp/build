#ifndef _BASE_H_
#define _BASE_H_

#include "BaseType.h"
#include "BaseDefine.h"
#include "BaseLib.h"
#include "BaseUtility.h"

#if defined(__WINDOWS__)
	#include "ExceptionPlus.h"
#elif defined(__LINUX__)
	#include "Exception.h"
#endif

#include "BitSet.h"
#include "Random.h"

#include "FLSeque.h"
#include "FLString.h"
#include "FLLog.h"

#include "Guid64.h"
#include "Misc.h"

#include "TimeManager.h"

#include "Pool.h"

#include "LogDefine.h"

//#include "Service/ServiceIDDefine.h"
//#include "Service/ServiceStatusDefine.h"
//#include "Service/ServiceRunStateDefine.h"
//#include "Service/ServiceManagerStatusDefine.h"

#endif