#include "GuidGenerator.h"

GuidGenerator::GuidGenerator( void )
{
	m_World = 0xffff;
	m_Type = 0xff;
	m_NextAvailableSerial.first = 0xff;
	m_NextAvailableSerial.second = 0xffffffff;
	m_CurrentSavedSerial.first = 0xff;
	m_CurrentSavedSerial.second = 0xffffffff;

	m_bInited = false;
}

GuidGenerator::~GuidGenerator( void )
{
	
}

bool GuidGenerator::Init( tuint16 World, tuint8 Type, tuint8 Carry, tuint32 Serial )
{
	__ENTER_FUNCTION

	bstMutexScopedLock LockGuard(m_bstMutex);

	AssertEx(m_bInited == false, "");

	m_World = World;
	m_Type = Type;
	m_NextAvailableSerial.first = Carry;
	m_NextAvailableSerial.second = Serial;
	m_CurrentSavedSerial.first = Carry;
	m_CurrentSavedSerial.second = Serial;

	m_bInited = true;

	return true;

	__LEAVE_FUNCTION
	return false;
}

Guid64 GuidGenerator::Gen( void )
{
	__ENTER_FUNCTION

	bstMutexScopedLock LockGuard(m_bstMutex);

	AssertEx(m_bInited == true, "");

	if (m_NextAvailableSerial >= m_CurrentSavedSerial)
	{
		IncreaseSerial(m_CurrentSavedSerial, 512);
	}

	Guid64 guid(m_World, m_Type, m_NextAvailableSerial.first, m_NextAvailableSerial.second);
	IncreaseSerial(m_NextAvailableSerial, 1);

	return guid;

	__LEAVE_FUNCTION
	return Guid64();
}

void GuidGenerator::Save(tint32 &guidType, tuint32 &carry, tuint32 &serial)
{
	GuidSerial Temp = m_CurrentSavedSerial;
	IncreaseSerial(Temp, 2048);

	guidType = m_Type;
	carry = Temp.first;
	serial = Temp.second;
}

void GuidGenerator::IncreaseSerial( GuidSerial &rSerial, tint32 nValue )
{
	__ENTER_FUNCTION

	const static tuint32 MaxSerialValue = 0xFFFF0000L;

	AssertEx(nValue > 0 && nValue <= 4096, "");

	tuint32 uTemp = rSerial.second + nValue;
	AssertEx(uTemp > rSerial.second, "");

	if (uTemp < MaxSerialValue)
	{
		rSerial.second = uTemp;
	}
	else
	{
		rSerial.first++;
		rSerial.second = (uTemp % MaxSerialValue);
	}

	__LEAVE_FUNCTION
}
