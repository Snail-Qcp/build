#ifndef _GUIDGENERATOR_H_
#define _GUIDGENERATOR_H_

#include "BaseType.h"
#include "BaseDefine.h"
#include "BaseLib.h"
#if defined(__WINDOWS__)
	#include "ExceptionPlus.h"
#elif defined(__LINUX__)
	#include "Exception.h"
#endif
#include "Guid64.h"

class GuidType
{
public:
	enum CONSTANT_VALUE
	{
		CHAR		= 0,	//��ɫ
		ITEM		= 1,
		EMAIL		= 2,
		MAX				    //����
	};
};

class GuidGenerator
{
public:
	GuidGenerator(void);
	~GuidGenerator(void);
private:
	typedef std::pair<tuint8, tuint32> GuidSerial;
public:
	bool	Init(tuint16 World, tuint8 Type, tuint8 Carry, tuint32 Serial);
	Guid64	Gen(void);

	void	Save(tint32 &guidType, tuint32 &carry, tuint32 &serial);
private:
	void	IncreaseSerial(GuidSerial &rSerial, tint32 nValue);
private:
	bstMutex	m_bstMutex;
	tuint16		m_World;
	tuint8		m_Type;
	GuidSerial	m_NextAvailableSerial;
	GuidSerial	m_CurrentSavedSerial;
private:
	bool		m_bInited;
};

#endif
