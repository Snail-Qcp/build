#include "GuidGeneratorEx.h"

GuidGeneratorEx::GuidGeneratorEx( void )
{
	m_World = 0xffff;
	m_NextAvailableSerial.first = 0xffffffff;
	m_NextAvailableSerial.second = 0xffff;
	m_bInited = false;
}

GuidGeneratorEx::~GuidGeneratorEx( void )
{
	
}

bool GuidGeneratorEx::Init(tuint16 World, tuint32 Carry, tuint16 Serial)
{
	__ENTER_FUNCTION

	bstMutexScopedLock LockGuard(m_bstMutex);

	AssertEx(m_bInited == false, "");

	m_World = World;
	m_NextAvailableSerial.first = Carry;
	m_NextAvailableSerial.second = Serial;
	m_bInited = true;
	return true;

	__LEAVE_FUNCTION
	return false;
}

GuidEx64 GuidGeneratorEx::Gen( void )
{
	__ENTER_FUNCTION

	bstMutexScopedLock LockGuard(m_bstMutex);

	AssertEx(m_bInited == true, "");

	GuidEx64 guid(m_World, m_NextAvailableSerial.first, m_NextAvailableSerial.second);
	IncreaseSerial(m_NextAvailableSerial);
	return guid;

	__LEAVE_FUNCTION
	return GuidEx64();
}


void GuidGeneratorEx::IncreaseSerial( GuidSerial &rSerial)
{
	__ENTER_FUNCTION

	const static tuint32 MaxSerialValue = 0xFF00L;

	tuint32 uTemp = rSerial.second + 1;
	AssertEx(uTemp > rSerial.second, "");

	if (uTemp < MaxSerialValue)
	{
		rSerial.second = uTemp;
	}
	else
	{
		rSerial.first++;
		rSerial.second = (uTemp % MaxSerialValue);
	}

	__LEAVE_FUNCTION
}
