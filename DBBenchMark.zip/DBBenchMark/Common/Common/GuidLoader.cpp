#include "GuidLoader.h"
#if defined(__WINDOWS__)
	#include "ExceptionPlus.h"
#elif defined(__LINUX__)
	#include "Exception.h"
#endif

enum GUIDLOAD_SEQ
{
	DB_TYPE =1,
	DB_CARRY,
	DB_SERIAL,
};