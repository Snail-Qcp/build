#ifndef _GUID64_EX_H_
#define _GUID64_EX_H_

#include "BaseType.h"

extern const tuint64 invalid_guid64;

union GuidEx64
{
private:
	tuint64	m_ullGuid;
	struct
	{
		tuint32	m_Carry;	//��λ����ÿ�� m_Serial �����޵�ʱ��+1��
		tuint16	m_Serial;	//���кţ�(��)123429
		tuint16	m_World;	//�����: (��)101
	}ig;
	struct  
	{
		tuint32	m_Low;
		tuint32	m_High;
	}val64bit;

public:
	GuidEx64(void) {Reset();}
	GuidEx64(tuint64 val64) {Assign(val64);}
	GuidEx64(tuint32 high32Bit, tuint32 low32Bit) {Assign(high32Bit, low32Bit);}
	GuidEx64(tuint16 worldID, tuint32 carry, tuint16 serial) {Assign(worldID, carry, serial);}
	GuidEx64(const GuidEx64 &r) {Assign(r.Get64Value());}
public:
	inline void Reset(void) {m_ullGuid = invalid_guid64;}
	inline bool	IsNull(void) const {return m_ullGuid == invalid_guid64;}
	inline void	Assign(tuint64 val64) {m_ullGuid=val64;}
	inline void	Assign(tuint32 high32Bit,tuint32 low32Bit) {val64bit.m_High=high32Bit;val64bit.m_Low=low32Bit;}
	inline void	Assign(tuint16 worldID, tuint32 carry, tuint16 serial) {ig.m_World = worldID;ig.m_Carry = carry;ig.m_Serial = serial;}
public:
	inline bool	operator ==(const GuidEx64& other)	const {return m_ullGuid == other.m_ullGuid;}
	inline bool	operator !=(const GuidEx64& other)	const {return m_ullGuid != other.m_ullGuid;}
	inline bool	operator >(const GuidEx64& other)		const {return m_ullGuid > other.m_ullGuid;}
	inline bool	operator <(const GuidEx64& other)		const {return m_ullGuid < other.m_ullGuid;}
	inline bool	operator >=(const GuidEx64& other)	const {return m_ullGuid >= other.m_ullGuid;}
	inline bool	operator <=(const GuidEx64& other)	const {return m_ullGuid <= other.m_ullGuid;}
	GuidEx64 & operator=(const GuidEx64 &r)
	{
		if (this != &r)
		{
			Assign(r.Get64Value());
		}
		return *this;
	}
public:
	inline tuint64	Get64Value(void)		const {return m_ullGuid;}
	inline tuint32	GetHigh32Value(void)	const {return val64bit.m_High;}
	inline tuint32	GetLow32Value(void)		const {return val64bit.m_Low;}
	inline tuint16	GetWorldID(void)		const {return ig.m_World;}
	inline tuint8	GetCarry(void)			const {return ig.m_Carry;}
	inline tuint32	GetSerial(void)			const {return ig.m_Serial;}
};

#endif
