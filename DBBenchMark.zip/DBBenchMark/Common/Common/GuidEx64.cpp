
#include "BaseLib.h"
#include "GuidEx64.h"
#include "Guid64.h"

const tuint64 invalid_guid64 = 0xFFFFFFFFFFFFFFFFull;

STATIC_ASSERT(sizeof(GuidEx64) == 8);
STATIC_ASSERT(sizeof(Guid64) == 8);
