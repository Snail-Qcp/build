#ifndef __UTILS_H__
#define __UTILS_H__

#include "Base.h"

extern std::vector<std::string> split(const std::string& chunk, const char delim);
extern tint32 GetRandomIntFromString(const std::string& intListStr, const char *pDelim = "|");
extern void GetIntListFromString(const std::string& intListStr, std::vector<int> &intVec, const char *pDelim = "|");
#endif