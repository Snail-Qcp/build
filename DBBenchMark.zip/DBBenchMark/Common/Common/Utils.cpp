#include "Utils.h"
#include <google/protobuf/stubs/strutil.h>

std::vector<std::string> split(const std::string& chunk, const char delim)
{
	std::vector<std::string> result;
	result.clear();

	std::stringstream ss(chunk);
	std::string item;

	while(std::getline(ss, item, delim)) 
		result.push_back(item);

	return result;
}

tint32 GetRandomIntFromString(const std::string& intListStr, const char *pDelim)
{
	std::vector<std::string> strList;
	google::protobuf::SplitStringUsing(intListStr, pDelim, &strList);
	tint32 sz = (tint32)strList.size();
	tint32 rndNum = Random::Gen(0, sz);
	return atoi(strList[rndNum].c_str());
}

void GetIntListFromString(const std::string& intListStr, std::vector<int> &intVec, const char *pDelim)
{
	std::vector<std::string> strList;
	google::protobuf::SplitStringUsing(intListStr, pDelim, &strList);
	tint32 sz = (tint32)strList.size();	
	intVec.reserve(sz);
	for (tint32 i = 0; i < sz; ++i)
	{
		intVec.push_back(atoi(strList[i].c_str()));
	}
}
