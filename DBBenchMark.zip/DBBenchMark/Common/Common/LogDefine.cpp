#include "Base.h"
#include "LogDefine.h"
//#include "Version.h"

//��ͨ��־
LOGDEF_IMPL(DebugLog, LogFormatType::NORMAL);
LOGDEF_IMPL(Login, LogFormatType::NORMAL);
LOGDEF_IMPL(Warning, LogFormatType::NORMAL);
LOGDEF_IMPL(Error, LogFormatType::NORMAL); 
LOGDEF_IMPL(DBAgentError, LogFormatType::NORMAL);
LOGDEF_IMPL(DBAgent, LogFormatType::NORMAL);
LOGDEF_IMPL(Lua, LogFormatType::NORMAL);
LOGDEF_IMPL(GMCommand, LogFormatType::NORMAL);
LOGDEF_IMPL(Pool, LogFormatType::NORMAL);
LOGDEF_IMPL(Packet, LogFormatType::NORMAL);
LOGDEF_IMPL(Scene, LogFormatType::NORMAL);
LOGDEF_IMPL(Guid, LogFormatType::NORMAL);
LOGDEF_IMPL(Exp, LogFormatType::NORMAL);
LOGDEF_IMPL(Oops, LogFormatType::NORMAL);
LOGDEF_IMPL(Player, LogFormatType::NORMAL);
LOGDEF_IMPL(Item, LogFormatType::NORMAL);
LOGDEF_IMPL(Protobuf, LogFormatType::NORMAL);
LOGDEF_IMPL(Building, LogFormatType::NORMAL);
LOGDEF_IMPL(SNet, LogFormatType::NORMAL);


void InitLogDefineModule( tint32 nWorldID )
{
	__ENTER_FUNCTION

	//��ͨ��־
	LOGDEF_INIT(ServerStatus, nWorldID);
	LOGDEF_INIT(DebugLog, nWorldID);
	LOGDEF_INIT(Login, nWorldID);
	LOGDEF_INIT(Warning, nWorldID);
	LOGDEF_INIT(Error, nWorldID);
	LOGDEF_INIT(DBAgentError, nWorldID);
	LOGDEF_INIT(DBAgent, nWorldID);
	LOGDEF_INIT(Lua, nWorldID);
	LOGDEF_INIT(Pool, nWorldID);
	LOGDEF_INIT(Packet, nWorldID);
	LOGDEF_INIT(Scene, nWorldID);
	LOGDEF_INIT(Efficiency, nWorldID);
	LOGDEF_INIT(CpuMem, nWorldID);
	LOGDEF_INIT(Guid, nWorldID);
	LOGDEF_INIT(Exp, nWorldID);
	LOGDEF_INIT(Oops, nWorldID);
	LOGDEF_INIT(Player, nWorldID);
	LOGDEF_INIT(Item, nWorldID);
	LOGDEF_INIT(Protobuf, nWorldID);
	LOGDEF_INIT(InvokeMonitor, nWorldID);
	LOGDEF_INIT(Building, nWorldID);
	LOGDEF_INIT(SNet, nWorldID);

	__LEAVE_FUNCTION
}







