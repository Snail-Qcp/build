#ifndef _GUIDGENERATOR_EX_H_
#define _GUIDGENERATOR_EX_H_

#include "BaseType.h"
#include "BaseDefine.h"
#include "BaseLib.h"
#if defined(__WINDOWS__)
	#include "ExceptionPlus.h"
#elif defined(__LINUX__)
	#include "Exception.h"
#endif
#include "GuidEx64.h"
#include "Common/TimeManager.h"
class GuidGeneratorEx
{
public:
	GuidGeneratorEx(void);
	~GuidGeneratorEx(void);
private:
	typedef std::pair<tuint32, tuint16> GuidSerial;
public:
	bool	 Init(tuint16 World, tuint32 Carry, tuint16 Serial);
	GuidEx64 Gen( void );
private:
	void	IncreaseSerial(GuidSerial &rSerial);
private:
	bstMutex	m_bstMutex;
	tuint16		m_World;
	GuidSerial	m_NextAvailableSerial;
private:
	bool		m_bInited;
};

#endif
