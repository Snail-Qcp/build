#ifndef _LOGDEFINE_H_
#define _LOGDEFINE_H_

#include "Log.h"
#include "Guid64.h"

//////////////////////////////////////////////////////////////////////////
//ͳ����־����
extern tint32 WorldID(void);

/*template<typename _LogSink>
inline void AuditLog(_LogSink &rLogSink, const tchar* szAuditIdentification, const Guid64 &rGuid, const tchar* szLog)
{
	tchar szBuff[4096] = {0};
	StringParser log(szBuff, sizeof(szBuff), "%s \1 %s \1 %d \1 %08X%08X \1 %s");
	log.Format(szAuditIdentification,International::GetAppKey().GetCText(),WorldID(),rGuid.GetHigh32Value(),rGuid.GetLow32Value(),szLog);
	szBuff[sizeof(szBuff) - 1] = '\0';
	rLogSink.Log(szBuff, false);
}

#define DEF_AUDITLOG(X) \
template<typename _LogSink, ParserRepeatArg1_##X(typename P)> \
inline void AuditLog(_LogSink &rLogSink, const tchar* szAuditIdentification, const Guid64 &rGuid, const tchar* szLog, ParserRepeatArg2_##X(P,p)) \
{ \
	tchar szFmt[4096] = {0}; \
	tsnprintf(szFmt, sizeof(szFmt), "%%s \1 %%s \1 %%d \1 %%08X%%08X \1 %s", szLog); \
	szFmt[sizeof(szFmt) - 1] = '\0'; \
	tchar szBuff[4096] = {0}; \
	StringParser log(szBuff, sizeof(szBuff), szFmt); \
	log.Format(szAuditIdentification,International::GetAppKey().GetCText(),WorldID(),rGuid.GetHigh32Value(),rGuid.GetLow32Value(),ParserRepeatArg1_##X(p)); \
	szBuff[sizeof(szBuff) - 1] = '\0'; \
	rLogSink.Log(szBuff, false); \
}*/

//////////////////////////////////////////////////////////////////////////
//����һ���µ�LogƵ������Ҫ�����������ļ������ӹ����崦
//LogDefine.h		1��
//LogDefine.cpp		2��
//LogService.cpp	2��

//����
LOGDEF_DECL(DebugLog);
//��ͨ��־
LOGDEF_DECL(Login);
LOGDEF_DECL(Warning);
LOGDEF_DECL(Error);
LOGDEF_DECL(DBAgentError);
LOGDEF_DECL(DBAgent);
LOGDEF_DECL(Lua);
LOGDEF_DECL(GMCommand);
LOGDEF_DECL(Pool);
LOGDEF_DECL(Packet);
LOGDEF_DECL(Scene);
LOGDEF_DECL(Guid);
LOGDEF_DECL(Exp);
LOGDEF_DECL(Oops);
LOGDEF_DECL(Player);
LOGDEF_DECL(Item);
LOGDEF_DECL(Protobuf);
LOGDEF_DECL(Building);
LOGDEF_DECL(SNet);


//////////////////////////////////////////////////////////////////////////
//��ʼ����־ģ��
void InitLogDefineModule(tint32 nWorldID);

//////////////////////////////////////////////////////////////////////////

class Obj_User;

//�������ڸ���ϵͳ��ӡ��־ʱ �����Ҫ����ö��ֵ ��Ӧ�ü�������
enum
{
	OP_UNKNOW							= 0,		//δ֪����
};


#define __ENTER_DEBUGLOG_TIME \
tuint32 sTime = gTimeManager.SysRunTime(); \

#define __LEAVE_DEBUGLOG_TIME(maxTime, fm, ...) \
tuint32 eTime = gTimeManager.SysRunTime(); \
tuint32 diffTime = eTime - sTime; \
if (diffTime > maxTime) \
{ \
} \
//DiskLog(LOGDEF_INST(DebugLog), "[T:%d], F:%s, L:%d, Function:%s,"##fm, diffTime, __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__); \

#endif