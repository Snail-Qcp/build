#pragma once

enum ItemCfgType
{
	ItemCfgType_CollectMaterials = 1,
	ItemCfgType_MonsterMaterials = 2,
	ItemCfgType_Product = 3,
	ItemCfgType_Drawings = 4,
	ItemCfgType_Skill = 5,  //���ܵ���
	ItemCfgType_Equip = 6,
	ItemCfgType_CollectTool = 7,
	ItemCfgType_Ride = 8,
	ItemCfgType_Money = 9,

	//
	ItemCfgType_Currency = 11,
	ItemCfgType_Card = 12,
	ItemCfgType_Appearance = 13,
	ItemCfgType_Other = 14,
	ItemCfgType_Max,
};

enum ItemPackType
{
	ItemPackType_Invalid = -1,
	ItemPackType_Bag = 0,
	ItemPackType_Storage,
	ItemPackType_EquipField,
	ItemPackType_Money,
	ItemPackType_Max,
};

enum BenchmarkType
{
	BT_START = 0,
	BT_CREATECHAR = BT_START,
	BT_USERSAVE,
	BT_USERLOAD,

	BT_MAX,
};

static const char sBenchmarkType[BT_MAX][32] = {
	"createchar",//BT_CREATECHAR
	"usersave",	//BT_USERSAVE
	"userload",	//BT_USERLOAD
};
