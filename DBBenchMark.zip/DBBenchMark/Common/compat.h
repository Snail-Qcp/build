#ifndef __COMPAT_H__
#define __COMPAT_H__

#include "net_def.h"

namespace NSRobot
{
	void sleep(int millionSec);

#ifdef WIN32
	int gettimeofday(struct timeval* tv, struct timezone* tz);
#endif
};

#endif