#ifndef ROBOTNAMEMANAGER_H
#define ROBOTNAMEMANAGER_H

#include <vector>
#include <string>

class RobotNameManager
{
public:
	virtual ~RobotNameManager(){}

public:
	 std::string GetOneName();
	 void  InitNamePool(const std::string &s);
	 void SetNameMark(const std::string &s) { m_CharMark = s;}
	 std::string GetNameMark() { return m_CharMark; }

public:
	 static RobotNameManager* getInstance()	{ return &m_inst; }
private:
	RobotNameManager(){}
private:
	static RobotNameManager m_inst;
private:
	std::vector<std::string> m_Names;
	std::string m_CharMark;
};

#endif //ROBOTNAMEMANAGER_H