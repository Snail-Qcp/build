#include "RobotNameManager.h"
#include "Table/Table_RobotName.h"

RobotNameManager RobotNameManager::m_inst;
std::string RobotNameManager::GetOneName()
{
	if (m_Names.empty())
	{
		return "Null";
	}
	static tint32 index = 0;
	if (index >= 0 && index < m_Names.size())
	{
		return m_Names[index++];
	}
	else
	{
		index = 0;
		return m_Names[index++];
	}
	return "Null";
}

void RobotNameManager::InitNamePool(const std::string &s)
{
	m_Names.clear();
	tint32 Count = GetTable_RobotNameCount();
	m_Names.reserve(Count * Count);
	for (tint32 i = 0; i < Count; ++i)
	{
		const Table_RobotName* pName = GetTable_RobotNameByIndex(i);
		std::string Fname = pName->GetFName();
		for (tint32 j = 0; j < Count; ++j)
		{
			const Table_RobotName* pName1 = GetTable_RobotNameByIndex(j);
			std::string Sname = pName1->GetSName();
			m_Names.push_back(Fname + "*" + Sname);
		}
	}
	//tint32 Size = (tint32)m_Names.size();
	//for (tint32 j = 0; j < Size; ++j)
	//{
	//	tint32 k = rand() % Size;
	//	tint32 m = rand() % Size;
	//	std::swap(m_Names[k], m_Names[m]);
	//}
	std::random_shuffle(m_Names.begin(), m_Names.end());

	//��������ǰ׺
	SetNameMark(s);
}
