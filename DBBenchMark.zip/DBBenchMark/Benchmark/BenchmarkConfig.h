#pragma once

#include "Base.h"
#include "BenchmarkDefine.h"

struct ServerConfig
{
	std::string dbServerHost;	//db server��ַ
	tint16		dbServerPort;	//db server�˿�
	tint16		playerNum;		//�������
	std::string accPrefix;		//�ʺ�ǰ׺
};

struct TestConfig
{
	tint32		interval;
};

class BenchmarkConfig
{
public:
	~BenchmarkConfig();

private:
	BenchmarkConfig();
	BenchmarkConfig(const BenchmarkConfig &);
	BenchmarkConfig &operator = (const BenchmarkConfig &);

public:
	typedef std::map<tint32, ServerConfig> TServerConfigMap;
	typedef std::map<std::string, TestConfig> TTestConfigMap;

public:
	static BenchmarkConfig &getInstance()
	{
		static BenchmarkConfig sInst;
		return sInst;
	}

	/**
	 * @brief load benchmark config
	 * @return bool, if success return true, else return false
	 */
	bool	Load();

	const TServerConfigMap &Servers() const { return m_mapServerConfig; }

	tint32	GetInterval(tint32 benchmarkType) const;

private:
	TServerConfigMap	m_mapServerConfig;
	TestConfig			m_testConfig[BT_MAX];
};
