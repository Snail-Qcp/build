#include "PlayerSimulator.h"
#include "Common/ExceptionPlus.h"
#include <ctime>
#include "BenchmarkConfig.h"
#include "Benchmark.h"

PlayerSimulator::PlayerSimulator() :m_Benchmark(nullptr)
{
	m_accName = "";
	memset(&m_data, 0, sizeof(m_data));
	memset(m_SimTypeTime, 0, sizeof(m_SimTypeTime));
}

PlayerSimulator::~PlayerSimulator()
{

}

void PlayerSimulator::Init(Benchmark *pBenchmark, const std::string &accName)
{
	AssertEx(nullptr != pBenchmark, "");
	m_Benchmark = pBenchmark;
	m_accName = accName;
	memset(&m_data, 0, sizeof(m_data));
	memset(m_SimTypeTime, 0, sizeof(m_SimTypeTime));
	
	std::string initAccName = accName + std::to_string(time(NULL));
	m_data.InitAsCreateNewChar(m_Benchmark->GenCharGuid(), initAccName.c_str(), initAccName.c_str(), 0, 0,1000,0);
	//���ɼٵ�������
	InitItemData();
	//���ɼ��ʼ�����
	InitEmailData();
	//���ɼ��̵�����
	InitShopData();
	m_data.m_scrapCard.charGuid = m_data.GetGuid();

	SimCreateChar(m_data.GetGuid(), m_accName);

	//�������ʱ��
	for (tint32 benchmarkType = BT_START; benchmarkType < BT_MAX; ++benchmarkType)
	{
		tint32 interval = BenchmarkConfig::getInstance().GetInterval(benchmarkType);
		if (interval != -1)
		{
			m_SimTypeTime[benchmarkType] = MilliSeconds() + (Random::Gen(1, interval));
		}
	}
}

void PlayerSimulator::InitItemData()
{
	m_data.m_ItemPack.InitAsCreateNewChar();
	m_data.m_ItemPack.m_count = DBItemPack::ITEM_TOTAL_COUNT;
	for (tint32 index = 0; index < m_data.m_ItemPack.m_count; ++index)
	{
		m_data.m_ItemPack.m_data[index].m_guid = m_Benchmark->GenItemGuid();
		m_data.m_ItemPack.m_data[index].m_charGuid = m_data.GetGuid();
	}
}

void PlayerSimulator::InitEmailData()
{
	m_data.m_emailPack.InitAsCreateNewChar();
	for (tint32 index = 0; index < 30; ++index)
	{
		AD_EMAILINFO *email = m_data.m_emailPack.m_emailData.Add();
		email->set_guid(m_Benchmark->GenEmailGuid());
		email->set_sender("system");
		email->set_receiver(m_accName);
		email->set_receiverguid(m_data.GetGuid());
		email->set_globalguid(0);
		email->set_type(0);
		email->set_createtime(time(NULL));
		email->set_state(0);
		email->set_title("test");
		email->set_content("content");
		email->set_senderguid(invalid_guid64);
	}
}

void PlayerSimulator::InitShopData()
{
	m_data.m_shopPack.InitAsCreateNewChar();
	m_data.m_shopPack.m_count = DBShopPack::ITEM_TOTAL_COUNT;
	for (tint32 index = 0; index < m_data.m_shopPack.m_count; ++index)
	{
		DBShopData &data = m_data.m_shopPack.m_data[index];
		data.m_charGuid = m_data.GetGuid();
		data.m_tId = 41002 + index;
		data.m_num = 10;
		data.m_discount = 8;
	}
}

void PlayerSimulator::Tick()
{
	SimCreateChar();
	SimUserLoad();
	SimUserSave();
}

tuint64 PlayerSimulator::MilliSeconds() const
{
	return std::clock() * 1000 / CLOCKS_PER_SEC;
}

bool PlayerSimulator::CheckInterval(tint32 benchmarkType) const
{
	if (benchmarkType < BT_START || benchmarkType >= BT_MAX)
		return false;

	tint32 interval = BenchmarkConfig::getInstance().GetInterval(benchmarkType);
	if (-1 == interval)
		return false;

	auto curTime = MilliSeconds();
	auto lastTime = m_SimTypeTime[benchmarkType];
	return (curTime - interval) >= lastTime ? true : false;
}

void PlayerSimulator::SimCreateChar(tuint64 guid /* = invalid_guid64 */, std::string accName /* = "" */)
{
	AD_USERSAVE pak;
	pak.set_savetype(AD_USERSAVE::ST_CREATE);
	AD_USER_DATA* userData = pak.mutable_userdata();
	if (guid == invalid_guid64)
	{
		if (CheckInterval(BT_CREATECHAR))
		{
			DBFullUserData data;
			std::string accName = m_accName + std::to_string(time(NULL));
			data.InitAsCreateNewChar(m_Benchmark->GenCharGuid(), accName.c_str(), accName.c_str(), 0, 0, 1000, 1000);
			userData->set_ubdata(((char*)(&(data.m_User))), sizeof(DBBaseUserData));
			userData->set_ubdataex1(((char*)(&(data.m_UserDataEx1))), sizeof(DBUserDataEX1));
			userData->set_ubdataex2(((char*)(&(data.m_UserDataEx2))), sizeof(DBUserDataEX2));
			userData->set_ubdataex3(((char*)(&(data.m_UserDataEx3RealTime))), sizeof(DBUserDataEX3RealTime));
			DBPlayerScrapCard scdata;
			scdata.charGuid = data.GetGuid();
			userData->set_scrapcard((char *)&scdata, sizeof(PlayerScrapCardData));
			m_Benchmark->Send(ADPackets::PACKET_AD_USERSAVE_PAK, pak);
			m_SimTypeTime[BT_CREATECHAR] = MilliSeconds();
		}
	}
	else
	{
		userData->set_ubdata(((char*)(&(m_data.m_User))), sizeof(DBBaseUserData));
		userData->set_ubdataex1(((char*)(&(m_data.m_UserDataEx1))), sizeof(DBUserDataEX1));
		userData->set_ubdataex2(((char*)(&(m_data.m_UserDataEx2))), sizeof(DBUserDataEX2));
		userData->set_ubdataex3(((char*)(&(m_data.m_UserDataEx3RealTime))), sizeof(DBUserDataEX3RealTime));
		DBPlayerScrapCard scdata;
		scdata.charGuid = m_data.GetGuid();
		userData->set_scrapcard((char *)&scdata, sizeof(PlayerScrapCardData));
		m_Benchmark->Send(ADPackets::PACKET_AD_USERSAVE_PAK, pak);
	}
}

void PlayerSimulator::SimUserSave()
{
	if (CheckInterval(BT_USERSAVE))
	{
		AD_USERSAVE pak;
		pak.set_savetype(AD_USERSAVE::ST_SAVE);
		AD_USER_DATA* userData = pak.mutable_userdata();
		userData->set_ubdata(((char*)(&(m_data.m_User))), sizeof(DBBaseUserData));
		userData->set_ubdataex1(((char*)(&(m_data.m_UserDataEx1))), sizeof(DBUserDataEX1));
		userData->set_ubdataex2(((char*)(&(m_data.m_UserDataEx2))), sizeof(DBUserDataEX2));
		userData->set_ubdataex3(((char*)(&(m_data.m_UserDataEx3RealTime))), sizeof(DBUserDataEX3RealTime));

		for (int i = 0; i < m_data.m_ItemPack.m_count; i++)
		{
			userData->add_itemdata((char*)(&(m_data.m_ItemPack.m_data[i])), sizeof(DBItemData));
		}
		for (int i = 0; i < m_data.m_CurrencyPack.m_count; i++)
		{
			userData->add_currencydata((char*)(&(m_data.m_CurrencyPack.m_data[i])), sizeof(DBCurrencyData));
		}

		for (int i = 0; i < m_data.m_emailPack.m_emailData.size(); ++i)
		{
			::AD_EMAILINFO* pInfo = userData->add_emialdata();
			if (!pInfo)
			{
				break;
			}
			pInfo->CopyFrom(m_data.m_emailPack.m_emailData.Get(i));
		}

		for (int i = 0; i < m_data.m_shopPack.m_count; i++)
		{
			userData->add_shopdata((char*)(&(m_data.m_shopPack.m_data[i])), sizeof(DBShopData));
		}

		userData->set_matchdata((char*)&(m_data.m_matchData),sizeof(DBMatchData) );

		userData->set_scrapcard((char*)&m_data.m_scrapCard, sizeof(DBPlayerScrapCard));

		m_Benchmark->Send(ADPackets::PACKET_AD_USERSAVE_PAK, pak);

		m_SimTypeTime[BT_USERSAVE] = MilliSeconds();
	}
}

void PlayerSimulator::SimUserLoad()
{
	if (CheckInterval(BT_USERLOAD))
	{
		AD_USERLOAD suPak;
		suPak.set_account(m_accName.c_str());
		suPak.set_usertype(AD_USERLOAD::UT_LOGIN_ACC_LOAD);
		m_Benchmark->Send(ADPackets::PACKET_AD_USERLOAD_PAK, suPak);

		m_SimTypeTime[BT_USERLOAD] = MilliSeconds();
	}
}
