#pragma once

#include <thread>
#include <unordered_map>
#include "Base.h"
#include "TcpClient.h"
#include "PlayerSimulator.h"
#include "Common/GuidGenerator.h"

typedef std::shared_ptr<std::thread> ThreadPtr;

struct ServerConfig;

class Benchmark : public TcpClient
{
public:
	Benchmark();
	~Benchmark();

	//����һ��ѹ��ʵ��
	static std::shared_ptr<std::thread> Create(tint32 serverId, const ServerConfig &cfg);

	//��ʼ��
	bool Init(tint32 serverId, const ServerConfig &cfg);

	//�߳����к���
	void Run();

	//��Ϣ���������
	virtual unsigned int process(SessionId sessionId, const BuffType* buff, unsigned int protoId, unsigned int size);

	//GUID����
	tuint64 GenCharGuid();
	tuint64 GenItemGuid();
	tuint64 GenEmailGuid();
private:
	virtual void	OnConnected();//���ӳɹ�
	virtual void	OnDisconnect();//�Ͽ�����
	bool	EnsureInited();
	void	OnInited();

	//GUID����
	void	SaveGuid();
	
	//ע��
	void	Regist();
	//ע�᷵��
	void	HandleDARegist(const BuffType *buff, tuint32 len);
private:
	typedef std::unordered_map<std::string, PlayerSimulator> TPlayerSimulatorMap;
	
private:
	tint32		m_ServerId;
	tint32		m_maxPlayerNum;
	std::string m_accPrefix;
	bool		m_bInited;	//�յ�DA_REGIST����Ϊ��ʼ���ɹ�

	TPlayerSimulatorMap	m_mapPlayerSimulator;
	GuidGenerator	m_CharGuidGen;
	GuidGenerator	m_ItemGuidGen;
	GuidGenerator	m_EmailGuidGen;
};
