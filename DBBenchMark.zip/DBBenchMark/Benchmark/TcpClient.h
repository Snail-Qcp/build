#pragma once

#include "Common/Base.h"
#include "network/net_unit.h"
#include "google/protobuf/message.h"

class TcpClient : public NSNet::INetIoAgent, NSNet::INetUnit
{
public:
	TcpClient();
	virtual ~TcpClient();

	virtual int onAddSession(SessionId id);
	virtual int onDeleteSession(SessionId id);
	virtual std::string identification() const;

	bool Connect(const char *ip, tint16 port);
	void Disconnect();
	bool IsConnected() const { return m_SessionId != invalid_id ? true : false; }

	virtual void OnConnected() {}
	virtual void OnDisconnect() {}

	void Tick();

	void CheckNet();
public:
	tint32 Send(tint32 protoId, google::protobuf::Message &msg);

private:
	tuint32		m_SessionId;
	std::string m_host;
	tuint16		m_port;
};
