#include "BenchmarkConfig.h"
#include "tinyxml2/tinyxml2.h"



BenchmarkConfig::BenchmarkConfig()
{
	m_mapServerConfig.clear();
	memset(m_testConfig, 0, sizeof(m_testConfig));
}

BenchmarkConfig::~BenchmarkConfig()
{

}

bool BenchmarkConfig::Load()
{
	tinyxml2::XMLDocument doc;
	tinyxml2::XMLError errXml = doc.LoadFile("./XmlConfig/benchmark_config.xml");
	if(tinyxml2::XML_SUCCESS != errXml)
	{
		AssertEx(false, "load benchmark config failed.");
	}

	const tinyxml2::XMLElement* parentRoot  = doc.RootElement();
	AssertEx(parentRoot, "");

	//����benchmark�ڵ�
	const tinyxml2::XMLElement* benchElem = parentRoot->FirstChildElement("benchmark");
	while (benchElem != nullptr)
	{
		tint32 serverId = benchElem->IntAttribute("serverid");
		if (serverId > 0)
		{
			ServerConfig cfg;
			cfg.dbServerHost = benchElem->Attribute("dbserverhost");
			cfg.dbServerPort = benchElem->IntAttribute("dbserverport");
			cfg.playerNum = benchElem->IntAttribute("playernum");
			cfg.accPrefix = benchElem->Attribute("accprefix");
			m_mapServerConfig[serverId] = cfg;
		}

		benchElem = benchElem->NextSiblingElement();
	}

	//����protocol�ڵ�
	const tinyxml2::XMLElement* testElement = parentRoot->FirstChildElement("test");
	while (testElement != nullptr)
	{
		TestConfig cfg;
		std::string testType = testElement->Attribute("type");
		cfg.interval = testElement->IntAttribute("interval");

		for (tint32 index = 0; index < BT_MAX; ++index)
		{
			if (testType.compare(sBenchmarkType[index]) == 0)
			{
				m_testConfig[index] = cfg;
				break;
			}
		}

		testElement = testElement->NextSiblingElement();
	}

	return true;
}

tint32 BenchmarkConfig::GetInterval(tint32 benchmarkType) const
{
	return (benchmarkType >= BT_START && benchmarkType < BT_MAX) ? m_testConfig[benchmarkType].interval : -1;
}
