#include "Benchmark.h"
#include "Common/ExceptionPlus.h"
#include "BenchmarkConfig.h"
#include "Packet/AD_Packet/AD_PBMessage.pb.h"
#include "Packet/AD_Packet/AD_PacketDefine.h"

using namespace ADPackets;
Benchmark::Benchmark()
{
	m_ServerId = invalid_id;
	m_mapPlayerSimulator.clear();
	m_bInited = false;
	m_maxPlayerNum = 0;
}

Benchmark::~Benchmark()
{

}

ThreadPtr Benchmark::Create(tint32 serverId, const ServerConfig &cfg)
{
	std::shared_ptr<Benchmark> ptrBench(new Benchmark());
	AssertEx(nullptr != ptrBench, "");
	AssertEx(ptrBench->Init(serverId, cfg), "");
	ThreadPtr ptrThread(new std::thread(&Benchmark::Run, ptrBench));
	return ptrThread;
}

bool Benchmark::Init(tint32 serverId, const ServerConfig &cfg)
{
	m_ServerId = serverId;
	m_maxPlayerNum = cfg.playerNum;
	m_accPrefix = cfg.accPrefix;
	m_mapPlayerSimulator.clear();

	Connect(cfg.dbServerHost.c_str(), cfg.dbServerPort);

	return true;
}

void Benchmark::Run()
{
	while (true)
	{
		if (EnsureInited())
		{
			for (auto &player : m_mapPlayerSimulator)
			{
				player.second.Tick();
			}
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}
}

bool Benchmark::EnsureInited()
{
	//�Զ�����
	TcpClient::CheckNet();
	//����tick
	TcpClient::Tick();

	return IsConnected() && m_bInited;
}

void Benchmark::OnInited()
{
	m_mapPlayerSimulator.clear();

	//�������
	for (tint32 i = 0; i < m_maxPlayerNum; ++i)
	{
		PlayerSimulator player;
		std::string accName = m_accPrefix + std::to_string(i);
		player.Init(this, accName);
		m_mapPlayerSimulator.insert(TPlayerSimulatorMap::value_type(accName, player));
	}

	m_bInited = true;
}

unsigned int Benchmark::process(SessionId sessionId, const BuffType* buff, unsigned int protoId, unsigned int size)
{
	if (protoId == ADPackets::PACKET_DA_REGIST_PAK)
	{
		HandleDARegist(buff, size);
	}

	return 0;
}

tuint64 Benchmark::GenCharGuid()
{
	return m_CharGuidGen.Gen().Get64Value();
}

tuint64 Benchmark::GenItemGuid()
{
	return m_ItemGuidGen.Gen().Get64Value();
}

tuint64 Benchmark::GenEmailGuid()
{
	return m_EmailGuidGen.Gen().Get64Value();
}

void Benchmark::OnConnected()
{
	Regist();
}

void Benchmark::OnDisconnect()
{
	m_bInited = false;
}

void Benchmark::SaveGuid()
{
	auto save = [=](GuidGenerator &guid) -> void {
		AD_GUID_SAVE guidPak;
		tint32 serverId = m_ServerId;
		tint32 guidType = invalid_id;
		tuint32 carry = 0, serial = 0;
		guid.Save(guidType, carry, serial);

		guidPak.set_serverid(serverId);
		guidPak.set_guidtype(guidType);
		guidPak.set_carry(carry);
		guidPak.set_serial(serial);
		Send(PACKET_AD_GUID_SAVE_PAK, guidPak);
	};

	save(m_CharGuidGen);
	save(m_ItemGuidGen);
	save(m_EmailGuidGen);
}

void Benchmark::Regist()
{
	AD_REGIST pak;
	pak.set_serverid(m_ServerId);
	for (int i = 0; i < 3; i++)
	{
		pak.add_guidtype(i);
	}

	Send(PACKET_AD_REGIST_PAK, pak);
}

void Benchmark::HandleDARegist(const BuffType *buff, tuint32 len)
{
	const tint32 header_size = 6;
	DA_REGIST msg;
	if (len > header_size && !msg.ParseFromArray(buff + header_size, len - header_size))
	{
		AssertEx(false, "");
	}

	for (int i = 0; i < msg.guidtype_size(); i++)
	{
		tint32 guidType = msg.guidtype(i);
		tuint8 carry = (tuint8)(msg.carry(i));
		tuint32 serial = msg.serial(i);

		switch(guidType)
		{
		case (tint32)GuidType::CHAR:
			{
				m_CharGuidGen.Init(m_ServerId, GuidType::CHAR, carry, serial);
			}
			break;
		case (tint32)GuidType::ITEM:
			{
				m_ItemGuidGen.Init(m_ServerId, GuidType::ITEM, carry, serial);
			}
			break;
		case (tint32)GuidType::EMAIL:
			{
				m_EmailGuidGen.Init(m_ServerId, GuidType::EMAIL, carry, serial);
			}
			break;
		default:
			break;
		}
	}

	OnInited();
}
