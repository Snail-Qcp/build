#include "TcpClient.h"

TcpClient::TcpClient() : NSNet::INetUnit(NSNet::INetIoAgent::m_pINetIo)
{
	m_SessionId = invalid_id;
}

TcpClient::~TcpClient()
{

}

int TcpClient::onAddSession(SessionId id) 
{
	m_SessionId = id;
	return 0;
}

int TcpClient::onDeleteSession(SessionId id)
{
	m_SessionId = invalid_id;
	return 0;
}

std::string TcpClient::identification() const
{
	return "TcpClient";
}

bool TcpClient::Connect(const char *ip, tint16 port)
{
	m_host = ip;
	m_port = port;

	NSNet::SocketInfo socInfo;
	socInfo.address = ip;
	socInfo.port = port;
	if (client(&socInfo, m_SessionId))
	{
		OnConnected();
		return true;
	}

	return false;
}

void TcpClient::Disconnect()
{
	NSNet::INetUnit::close(m_SessionId);
	OnDisconnect();
}

void TcpClient::Tick()
{
	tick();
}

void TcpClient::CheckNet()
{
	if (!IsConnected())
	{
		Connect(m_host.c_str(), m_port);
	}
}

tint32 TcpClient::Send(tint32 protoId, google::protobuf::Message &msg)
{
	return send(m_SessionId, msg, protoId);
}
