#pragma once

#include "Base.h"
#include "dbStruct/DBStruct_User.h"
#include "Packet/AD_Packet/AD_PacketDefine.h"
#include "BenchmarkDefine.h"

class Benchmark;

class PlayerSimulator
{
public:
	PlayerSimulator();
	virtual ~PlayerSimulator();

	void	Init(Benchmark *pBenchmark, const std::string &accName);

	void	Tick();

private:
	void	SimCreateChar(tuint64 guid = invalid_guid64, std::string accName = "");
	void	SimUserSave();
	void	SimUserLoad();

private:
	void	InitItemData();
	void	InitEmailData();
	void	InitShopData();

private:
	tuint64	MilliSeconds() const;
	bool	CheckInterval(tint32 benchmarkType) const;
private:
	Benchmark		*m_Benchmark;
	std::string		m_accName;
	DBFullUserData	m_data;
	tuint64			m_SimTypeTime[BT_MAX];
};
