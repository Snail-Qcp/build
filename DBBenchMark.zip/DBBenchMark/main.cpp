#include "Base.h"
#include "Common/compat.h"
 #include "PacketDef.h"
#include "Table/TableManager.h"
#include "Util/RobotNameManager.h"
#include "Util/CatchDump.h"
#include "Benchmark/BenchmarkConfig.h"
#include "Table/Table_RobotName.h"
#include "Benchmark/Benchmark.h"
#include "Common/ExceptionPlus.h"
//#include "vld.h"

#if defined(__WINDOWS__)
CatchDumpFile::CDumpCatch g_DumpCatch;
#endif

void InitDBBenchMark(const std::string &charNamePrefix)
{
	InitTable_RobotNameTable("Config/RobotName.txt");
	InitTable();

	RobotNameManager::getInstance()->InitNamePool(charNamePrefix);
	BenchmarkConfig::getInstance().Load();
}

int main(int argc, char* argv[])
{
	std::cout << "start bench" << std::endl;
	srand(static_cast<tuint32>(_ansitime()));
	
	std::string CharName;
	if ( argc>=2 )
	{
		CharName = argv[1];
	}
	else
	{
		std::cout<<"Please Input CharName Mark........." << std::endl;
		std::cin >> CharName;
		std::cout << "Set CharName Mark OK........" << std::endl;
	}
	
	//��ʼ��
	InitDBBenchMark(CharName);

	std::list<ThreadPtr> lstThreads;
	//�������
	for (auto it = BenchmarkConfig::getInstance().Servers().begin(); it != BenchmarkConfig::getInstance().Servers().end(); ++it)
	{
		ThreadPtr ptr = Benchmark::Create(it->first, it->second);
		AssertEx(ptr != nullptr, "");
		lstThreads.emplace_back(ptr);
	}

	for (auto it = lstThreads.begin(); it != lstThreads.end(); ++it)
	{
		(*it)->join();
	}

	return EXIT_SUCCESS;
}
